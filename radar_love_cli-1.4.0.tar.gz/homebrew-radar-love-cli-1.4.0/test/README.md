# 🧪 Test Folder

This folder contains shell-based smoke tests or sanity checks used by GitHub Actions, pre-commit hooks, or local development.

You can place test scripts here (e.g. `test_sanity.sh`) to validate CLI behavior or output.
